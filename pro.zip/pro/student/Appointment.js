document
  .getElementById("appointmentForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    var studentName = document.getElementById("studentName").value;
    var teacherName = document.getElementById("teacherName").value;
    var email = document.getElementById("email").value;
    var date = document.getElementById("date").value;
    var time = document.getElementById("time").value;

    var confirmationDetails = `
        <strong>Student Name:</strong> ${studentName}<br>
        <strong>Teacher Name:</strong> ${teacherName}<br>
        <strong>Email:</strong> ${email}<br>
        <strong>Date:</strong> ${date}<br>
        <strong>Time:</strong> ${time}
    `;

    document.getElementById("confirmationDetails").innerHTML =
      confirmationDetails;
    document.getElementById("confirmation").classList.remove("hidden");
    document.getElementById("appointmentForm").reset();
  });
