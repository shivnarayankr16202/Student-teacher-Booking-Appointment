// // Function to dynamically add a new nav-link
// function addNavLink(href, iconSrc, text) {
//   const navLinks = document.getElementById("nav-links");
//   const newLink = document.createElement("a");
//   newLink.href = href;

//   const icon = document.createElement("img");
//   icon.src = iconSrc;
//   icon.alt = `${text} Icon`;

//   newLink.appendChild(icon);
//   newLink.appendChild(document.createTextNode(text));

//   navLinks.appendChild(newLink);
// }

// // Example usage of addNavLink function
// addNavLink("#blog", "blog-icon.gif", "Blog");

// // Function to change the logo text
// function changeLogoText(newText) {
//   document.querySelector(".logo").textContent = newText;
// }

// // Example usage of changeLogoText function
// changeLogoText("NewLogo");
