function editTeacher(button) {
  const row = button.parentNode.parentNode;
  const name = row.cells[0].textContent;
  const subject = row.cells[1].textContent;
  document.getElementById("teacherName").value = name;
  document.getElementById("teacherSubject").value = subject;
  document.getElementById("rowIndex").value = row.rowIndex;
  document.getElementById("editForm").style.display = "block";
}

function deleteTeacher(button) {
  const row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}

function saveTeacher(event) {
  event.preventDefault();
  const rowIndex = document.getElementById("rowIndex").value;
  const table = document.getElementById("teacherTable").tBodies[0];
  const row = table.rows[rowIndex - 1];
  row.cells[0].textContent = document.getElementById("teacherName").value;
  row.cells[1].textContent = document.getElementById("teacherSubject").value;
  document.getElementById("editForm").style.display = "none";
}

function cancelEdit() {
  document.getElementById("editForm").style.display = "none";
}
