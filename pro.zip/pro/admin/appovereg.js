function approveRegistration(button) {
  const row = button.parentNode.parentNode;
  const name = row.cells[0].textContent;
  alert(`${name}'s registration has been approved!`);
  row.parentNode.removeChild(row);
}

function deleteRegistration(button) {
  const row = button.parentNode.parentNode;
  const name = row.cells[0].textContent;
  if (confirm(`Are you sure you want to delete ${name}'s registration?`)) {
    row.parentNode.removeChild(row);
  }
}
